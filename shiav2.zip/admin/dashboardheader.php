<!-- Page Wrapper -->
<div id="wrapper">

<!-- Sidebar -->
<?php require_once(get_template_directory(). '/admin/sidebar.php'); ?>
<!-- End of Sidebar -->

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

   <!-- Main Content -->
   <div id="content">

       <!-- Topbar -->
       <?php require_once(get_template_directory(). '/admin/admintopbar.php'); ?>
       <!-- End of Topbar -->