<?php wp_footer(); ?>
<script src="https://code.jquery.com/ui/1.10.4/jquery-ui.js"></script>
</body>
</html>
